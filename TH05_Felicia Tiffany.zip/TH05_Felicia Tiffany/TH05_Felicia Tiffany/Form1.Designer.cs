﻿namespace TH05_Felicia_Tiffany
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblproduct = new System.Windows.Forms.Label();
            this.lblcat = new System.Windows.Forms.Label();
            this.lbldetails = new System.Windows.Forms.Label();
            this.data_product = new System.Windows.Forms.DataGridView();
            this.data_category = new System.Windows.Forms.DataGridView();
            this.bt_all = new System.Windows.Forms.Button();
            this.bt_filter = new System.Windows.Forms.Button();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.lblnamacat = new System.Windows.Forms.Label();
            this.tb_category = new System.Windows.Forms.TextBox();
            this.bt_addcat = new System.Windows.Forms.Button();
            this.bt_removecat = new System.Windows.Forms.Button();
            this.lblnamaproduct = new System.Windows.Forms.Label();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.lblcatproduct = new System.Windows.Forms.Label();
            this.lblharga = new System.Windows.Forms.Label();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.lblstock = new System.Windows.Forms.Label();
            this.tb_stock = new System.Windows.Forms.TextBox();
            this.bt_add = new System.Windows.Forms.Button();
            this.bt_remove = new System.Windows.Forms.Button();
            this.bt_edit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.data_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_category)).BeginInit();
            this.SuspendLayout();
            // 
            // lblproduct
            // 
            this.lblproduct.AutoSize = true;
            this.lblproduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblproduct.Location = new System.Drawing.Point(12, 22);
            this.lblproduct.Name = "lblproduct";
            this.lblproduct.Size = new System.Drawing.Size(71, 20);
            this.lblproduct.TabIndex = 0;
            this.lblproduct.Text = "Product";
            // 
            // lblcat
            // 
            this.lblcat.AutoSize = true;
            this.lblcat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcat.Location = new System.Drawing.Point(543, 22);
            this.lblcat.Name = "lblcat";
            this.lblcat.Size = new System.Drawing.Size(81, 20);
            this.lblcat.TabIndex = 1;
            this.lblcat.Text = "Category";
            // 
            // lbldetails
            // 
            this.lbldetails.AutoSize = true;
            this.lbldetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldetails.Location = new System.Drawing.Point(12, 256);
            this.lbldetails.Name = "lbldetails";
            this.lbldetails.Size = new System.Drawing.Size(65, 20);
            this.lbldetails.TabIndex = 2;
            this.lbldetails.Text = "Details";
            // 
            // data_product
            // 
            this.data_product.AllowUserToResizeColumns = false;
            this.data_product.AllowUserToResizeRows = false;
            this.data_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.data_product.Location = new System.Drawing.Point(16, 45);
            this.data_product.MultiSelect = false;
            this.data_product.Name = "data_product";
            this.data_product.RowHeadersVisible = false;
            this.data_product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.data_product.Size = new System.Drawing.Size(502, 191);
            this.data_product.TabIndex = 3;
            this.data_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.data_product_CellClick);
            // 
            // data_category
            // 
            this.data_category.AllowUserToResizeColumns = false;
            this.data_category.AllowUserToResizeRows = false;
            this.data_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.data_category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.data_category.Location = new System.Drawing.Point(547, 45);
            this.data_category.MultiSelect = false;
            this.data_category.Name = "data_category";
            this.data_category.RowHeadersVisible = false;
            this.data_category.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.data_category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.data_category.Size = new System.Drawing.Size(212, 151);
            this.data_category.TabIndex = 4;
            this.data_category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.data_category_CellClick);
            // 
            // bt_all
            // 
            this.bt_all.Location = new System.Drawing.Point(326, 19);
            this.bt_all.Name = "bt_all";
            this.bt_all.Size = new System.Drawing.Size(47, 23);
            this.bt_all.TabIndex = 5;
            this.bt_all.Text = "All";
            this.bt_all.UseVisualStyleBackColor = true;
            this.bt_all.Click += new System.EventHandler(this.bt_all_Click);
            // 
            // bt_filter
            // 
            this.bt_filter.Location = new System.Drawing.Point(379, 19);
            this.bt_filter.Name = "bt_filter";
            this.bt_filter.Size = new System.Drawing.Size(47, 23);
            this.bt_filter.TabIndex = 6;
            this.bt_filter.Text = "Filter";
            this.bt_filter.UseVisualStyleBackColor = true;
            this.bt_filter.Click += new System.EventHandler(this.bt_filter_Click);
            // 
            // cb_filter
            // 
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(432, 21);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(85, 21);
            this.cb_filter.TabIndex = 7;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // lblnamacat
            // 
            this.lblnamacat.AutoSize = true;
            this.lblnamacat.Location = new System.Drawing.Point(544, 205);
            this.lblnamacat.Name = "lblnamacat";
            this.lblnamacat.Size = new System.Drawing.Size(41, 13);
            this.lblnamacat.TabIndex = 8;
            this.lblnamacat.Text = "Nama :";
            // 
            // tb_category
            // 
            this.tb_category.Location = new System.Drawing.Point(591, 202);
            this.tb_category.Name = "tb_category";
            this.tb_category.Size = new System.Drawing.Size(132, 20);
            this.tb_category.TabIndex = 9;
            // 
            // bt_addcat
            // 
            this.bt_addcat.BackColor = System.Drawing.Color.LightGreen;
            this.bt_addcat.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bt_addcat.Location = new System.Drawing.Point(591, 228);
            this.bt_addcat.Name = "bt_addcat";
            this.bt_addcat.Size = new System.Drawing.Size(63, 37);
            this.bt_addcat.TabIndex = 10;
            this.bt_addcat.Text = "Add Category";
            this.bt_addcat.UseVisualStyleBackColor = false;
            this.bt_addcat.Click += new System.EventHandler(this.bt_addcat_Click);
            // 
            // bt_removecat
            // 
            this.bt_removecat.BackColor = System.Drawing.Color.LightSalmon;
            this.bt_removecat.Location = new System.Drawing.Point(660, 228);
            this.bt_removecat.Name = "bt_removecat";
            this.bt_removecat.Size = new System.Drawing.Size(63, 37);
            this.bt_removecat.TabIndex = 11;
            this.bt_removecat.Text = "Remove Category";
            this.bt_removecat.UseVisualStyleBackColor = false;
            this.bt_removecat.Click += new System.EventHandler(this.bt_removecat_Click);
            // 
            // lblnamaproduct
            // 
            this.lblnamaproduct.AutoSize = true;
            this.lblnamaproduct.Location = new System.Drawing.Point(27, 286);
            this.lblnamaproduct.Name = "lblnamaproduct";
            this.lblnamaproduct.Size = new System.Drawing.Size(41, 13);
            this.lblnamaproduct.TabIndex = 12;
            this.lblnamaproduct.Text = "Nama :";
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(73, 283);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(152, 20);
            this.tb_nama.TabIndex = 13;
            // 
            // lblcatproduct
            // 
            this.lblcatproduct.AutoSize = true;
            this.lblcatproduct.Location = new System.Drawing.Point(13, 315);
            this.lblcatproduct.Name = "lblcatproduct";
            this.lblcatproduct.Size = new System.Drawing.Size(55, 13);
            this.lblcatproduct.TabIndex = 14;
            this.lblcatproduct.Text = "Category :";
            // 
            // lblharga
            // 
            this.lblharga.AutoSize = true;
            this.lblharga.Location = new System.Drawing.Point(26, 341);
            this.lblharga.Name = "lblharga";
            this.lblharga.Size = new System.Drawing.Size(42, 13);
            this.lblharga.TabIndex = 15;
            this.lblharga.Text = "Harga :";
            // 
            // cb_category
            // 
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Location = new System.Drawing.Point(74, 309);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(85, 21);
            this.cb_category.TabIndex = 16;
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(74, 336);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(85, 20);
            this.tb_harga.TabIndex = 17;
            this.tb_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_harga_KeyPress);
            // 
            // lblstock
            // 
            this.lblstock.AutoSize = true;
            this.lblstock.Location = new System.Drawing.Point(26, 366);
            this.lblstock.Name = "lblstock";
            this.lblstock.Size = new System.Drawing.Size(41, 13);
            this.lblstock.TabIndex = 18;
            this.lblstock.Text = "Stock :";
            // 
            // tb_stock
            // 
            this.tb_stock.Location = new System.Drawing.Point(73, 362);
            this.tb_stock.Name = "tb_stock";
            this.tb_stock.Size = new System.Drawing.Size(85, 20);
            this.tb_stock.TabIndex = 19;
            this.tb_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stock_KeyPress);
            // 
            // bt_add
            // 
            this.bt_add.BackColor = System.Drawing.Color.LightGreen;
            this.bt_add.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bt_add.Location = new System.Drawing.Point(173, 336);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(55, 37);
            this.bt_add.TabIndex = 20;
            this.bt_add.Text = "Add Product";
            this.bt_add.UseVisualStyleBackColor = false;
            this.bt_add.Click += new System.EventHandler(this.bt_add_Click);
            // 
            // bt_remove
            // 
            this.bt_remove.BackColor = System.Drawing.Color.LightSalmon;
            this.bt_remove.Location = new System.Drawing.Point(288, 336);
            this.bt_remove.Name = "bt_remove";
            this.bt_remove.Size = new System.Drawing.Size(55, 37);
            this.bt_remove.TabIndex = 21;
            this.bt_remove.Text = "Remove Product";
            this.bt_remove.UseVisualStyleBackColor = false;
            this.bt_remove.Click += new System.EventHandler(this.bt_remove_Click);
            // 
            // bt_edit
            // 
            this.bt_edit.BackColor = System.Drawing.Color.Khaki;
            this.bt_edit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bt_edit.Location = new System.Drawing.Point(230, 336);
            this.bt_edit.Name = "bt_edit";
            this.bt_edit.Size = new System.Drawing.Size(55, 37);
            this.bt_edit.TabIndex = 22;
            this.bt_edit.Text = "Edit Product";
            this.bt_edit.UseVisualStyleBackColor = false;
            this.bt_edit.Click += new System.EventHandler(this.bt_edit_Click);
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(777, 388);
            this.Controls.Add(this.bt_edit);
            this.Controls.Add(this.bt_remove);
            this.Controls.Add(this.bt_add);
            this.Controls.Add(this.tb_stock);
            this.Controls.Add(this.lblstock);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.cb_category);
            this.Controls.Add(this.lblharga);
            this.Controls.Add(this.lblcatproduct);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.lblnamaproduct);
            this.Controls.Add(this.bt_removecat);
            this.Controls.Add(this.bt_addcat);
            this.Controls.Add(this.tb_category);
            this.Controls.Add(this.lblnamacat);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.bt_filter);
            this.Controls.Add(this.bt_all);
            this.Controls.Add(this.data_category);
            this.Controls.Add(this.data_product);
            this.Controls.Add(this.lbldetails);
            this.Controls.Add(this.lblcat);
            this.Controls.Add(this.lblproduct);
            this.Name = "Shop";
            this.Text = "Shop";
            this.Load += new System.EventHandler(this.Shop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.data_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblproduct;
        private System.Windows.Forms.Label lblcat;
        private System.Windows.Forms.Label lbldetails;
        private System.Windows.Forms.DataGridView data_product;
        private System.Windows.Forms.DataGridView data_category;
        private System.Windows.Forms.Button bt_all;
        private System.Windows.Forms.Button bt_filter;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.Label lblnamacat;
        private System.Windows.Forms.TextBox tb_category;
        private System.Windows.Forms.Button bt_addcat;
        private System.Windows.Forms.Button bt_removecat;
        private System.Windows.Forms.Label lblnamaproduct;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.Label lblcatproduct;
        private System.Windows.Forms.Label lblharga;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.Label lblstock;
        private System.Windows.Forms.TextBox tb_stock;
        private System.Windows.Forms.Button bt_add;
        private System.Windows.Forms.Button bt_remove;
        private System.Windows.Forms.Button bt_edit;
    }
}

