﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05_Felicia_Tiffany
{
    public partial class Shop : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil;
        DataTable dtCategory = new DataTable();
        int count = 6; string id;
        int selectedindex = 0;
        int selectedcat = 0;
        public Shop()
        {
            InitializeComponent();
        }

        private void Shop_Load(object sender, EventArgs e)
        {
            cb_filter.Enabled = false;
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "jas");
            dtCategory.Rows.Add("C2", "t-Shirt");
            dtCategory.Rows.Add("C3", "rok");
            dtCategory.Rows.Add("C4", "celana");
            dtCategory.Rows.Add("C5", "cawat");
            data_category.DataSource = dtCategory;

            dtProdukTampil = dtProdukSimpan;
            data_product.DataSource = dtProdukTampil;

            cb_category.DataSource = dtCategory;
            cb_category.DisplayMember = "Nama Category";
            cb_category.ValueMember = "ID Category";
            cb_category.SelectedIndex = -1;
        }

        private void bt_addcat_Click(object sender, EventArgs e)
        {
            if (tb_category.Text == "")
            {
                MessageBox.Show("Error");
            }
            else
            {
                bool yn = true;
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString() == tb_category.Text)
                    {
                        yn = false;
                        break;
                    }
                }
                if (yn == false)
                {
                    MessageBox.Show("Category Already Exist");
                }
                else
                {
                    dtCategory.Rows.Add("C" + count, tb_category.Text);
                    count++;
                    tb_category.Text = "";
                }
            }
        }
        private void Number(char x)
        {
            int index = 0; bool tf = false;
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i][0].ToString().ToLower()[0] == x)
                {
                    index = i;
                    tf = true;
                }
            }
            if (tf)
            {
                char nomor = dtProdukSimpan.Rows[index][0].ToString()[3];
                int no = nomor - '0' + 1;
                if (no < 10)
                {
                    id = tb_nama.Text[0] + "00" + no.ToString();
                }
                else if (no >= 10)
                {
                    id = tb_nama.Text[0] + "0" + no.ToString();
                }
                else if (no >= 100)
                {
                    id = tb_nama.Text[0] + no.ToString();
                }
            }
            else
            {
                id = tb_nama.Text[0] + "001";
            }
        }
        
        private void bt_add_Click(object sender, EventArgs e)
        {
            if (tb_nama.Text != "" && cb_category.SelectedIndex != -1 && tb_harga.Text != "" && tb_stock.Text != "" && tb_stock.Text != "0")
            {
                Number(tb_nama.Text.ToString().ToLower()[0]);
                dtProdukSimpan.Rows.Add(id.ToUpper(), tb_nama.Text, tb_harga.Text, tb_stock.Text, cb_category.SelectedValue);
                tb_nama.Text = "";
                tb_harga.Text = "";
                tb_stock.Text = "";
                cb_category.SelectedIndex = -1;
                data_product.DataSource = dtProdukSimpan;
            }
            else
            {
                MessageBox.Show("ERROR!");
            }

        }

        private void tb_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void tb_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void bt_filter_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = true;
            cb_filter.DataSource = dtCategory;
            cb_filter.DisplayMember = "Nama Category";
            cb_filter.ValueMember = "ID Category";
            cb_filter.SelectedIndex = -1;
        }

        private void bt_all_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = false;
            data_product.DataSource = dtProdukSimpan;
        }

        private void bt_removecat_Click(object sender, EventArgs e)
        {
            if (tb_category.Text == "")
            {
                MessageBox.Show("ERROR");
            }
            else
            {
                string removecat = dtCategory.Rows[selectedcat][0].ToString();
                dtCategory.Rows.RemoveAt(selectedcat);
                data_category.DataSource = dtCategory;
                cb_category.DataSource = dtCategory;
                cb_category.DisplayMember = "Nama Category";
                cb_category.ValueMember = "ID Category";

                List<int> removeid = new List<int>();
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][4].ToString() == removecat)
                    {
                        removeid.Add(i);
                    }
                }
                foreach (int i in removeid)
                {
                    RemoveItem(removecat);
                }
                dtProdukTampil = dtProdukSimpan;
                data_product.DataSource = dtProdukTampil;
            }
        }
        private void RemoveItem (string x)
        {
            List<int> removeid = new List<int>();
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i][4].ToString() == x)
                {
                    removeid.Add(i);
                    break;
                }
            }
            dtProdukSimpan.Rows.RemoveAt(removeid[0]);
        }

        private void data_category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow selectedrow = data_category.Rows[e.RowIndex];
            tb_category.Text = selectedrow.Cells[1].Value.ToString();
            selectedcat = e.RowIndex;
        }

        private void data_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow selectedrow = data_product.Rows[e.RowIndex];
            tb_nama.Text = selectedrow.Cells[1].Value.ToString();
            tb_harga.Text = selectedrow.Cells[2].Value.ToString();
            tb_stock.Text = selectedrow.Cells[3].Value.ToString();
            string idcategory = selectedrow.Cells[4].Value.ToString();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i]["ID Category"].ToString() == idcategory)
                {
                    cb_category.SelectedIndex = i;
                }
            }
            selectedindex = e.RowIndex;
        }

        private void bt_edit_Click(object sender, EventArgs e)
        {
            if (tb_nama.Text == "" || cb_category.SelectedIndex == -1 || tb_harga.Text == "" || tb_stock.Text == "")
            {
                MessageBox.Show("ERROR");
            }
            else
            {
                if (tb_stock.Text == "0")
                {
                    dtProdukSimpan.Rows.RemoveAt(selectedindex);
                }
                else
                {
                    dtProdukSimpan.Rows[selectedindex][0] = id;
                    dtProdukSimpan.Rows[selectedindex][1] = tb_nama.Text;
                    dtProdukSimpan.Rows[selectedindex][2] = tb_harga.Text;
                    dtProdukSimpan.Rows[selectedindex][3] = tb_stock.Text;
                    dtProdukSimpan.Rows[selectedindex][4] = cb_category.SelectedValue;
                }
                dtProdukTampil = dtProdukSimpan;
                data_product.DataSource = dtProdukTampil;

                tb_nama.Text = "";
                tb_harga.Text = "";
                tb_stock.Text = "";
                cb_category.SelectedIndex = -1;
            }
        }

        private void bt_remove_Click(object sender, EventArgs e)
        {
            if (dtProdukSimpan.Rows.Count > 0)
            {
                if (tb_nama.Text == "" || cb_category.SelectedIndex == -1 || tb_harga.Text == "" || tb_stock.Text == "")
                {
                    MessageBox.Show("ERROR");
                }
                else
                {
                    DataGridViewRow selectedRow = data_product.SelectedRows[0];
                    string selectedProductId = selectedRow.Cells["ID Product"].Value.ToString();

                    int selectedIndexInMain = -1;
                    for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                    {
                        if (dtProdukSimpan.Rows[i]["ID Product"].ToString() == selectedProductId)
                        {
                            selectedIndexInMain = i;
                            break;
                        }
                    }
                    if (selectedIndexInMain != -1)
                    {
                        dtProdukSimpan.Rows.RemoveAt(selectedIndexInMain);

                        if (cb_filter.Enabled)
                        {
                            cb_filter_SelectedIndexChanged(sender, e);
                        }
                        else
                        {
                            data_product.DataSource = dtProdukSimpan;
                        }
                        tb_nama.Text = "";
                        cb_category.SelectedIndex = -1;
                        tb_harga.Text = "";
                        tb_stock.Text = "";
                    }
                }
            }
            else
            {
                MessageBox.Show("ERROR");
            }
        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_filter.Enabled == true)
            {
                if (cb_filter.SelectedIndex != -1)
                {
                    dtProdukTampil = new DataTable();
                    int index = cb_filter.SelectedIndex;

                    dtProdukTampil.Columns.Add("ID Product");
                    dtProdukTampil.Columns.Add("Nama Product");
                    dtProdukTampil.Columns.Add("Harga");
                    dtProdukTampil.Columns.Add("Stock");
                    dtProdukTampil.Columns.Add("ID Category");
                    foreach (DataRow x in dtProdukSimpan.Rows)
                    {
                        if (x["ID Category"] == dtCategory.Rows[index]["ID Category"].ToString())
                        {
                            dtProdukTampil.Rows.Add(x[0], x[1], x[2], x[3], x[4]);
                        }
                    }
                    data_product.DataSource = dtProdukTampil;
                }
                else
                {
                    data_product.DataSource = dtProdukSimpan;
                }
            }
            else
            {
                data_product.DataSource = dtProdukSimpan;
            }
        }
    }
}